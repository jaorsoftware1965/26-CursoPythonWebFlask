# -------------------------------------------------------------------------------
# Programación para Web con Python y Flask
# Desarrollo de una Calculadora con AJAX
# -------------------------------------------------------------------------------

# Se importan las librerias
# pip install flask
from   flask import Flask, jsonify, render_template, request
import time

# Crea el objeto Flask
app = Flask(__name__)

# Define la ruta principal
@app.route("/")

# Define la función principal
def main():
    # Carga template main.html
    return render_template('main.html')


# Define la ruta para la calculadora
@app.route("/api/calc")

# Define la función para calcular
def calculadora():
    # Obtiene los valores por el metodo get
    val1 = int(request.args.get('a', 0))
    val2 = int(request.args.get('b', 0))

    # Verifica que b sea diferente de 0
    if val2 != 0:
        # Realiza la división
        div = val1/val2
    else:
        # No procede la división
        div = 'na'

    # Retorna el resultado en JSON    
    return jsonify({
        "agua"     :  val1,
        "pan"      :  val2,
        "resSuma"  :  val1+val2,
        "resMult"  :  val1*val2,
        "resRest"  :  val1-val2,
        "resDivi"  :  div,
    })

# Función principal
if __name__ == '__main__':

    # Ejecuta el Servidor en Debug
    app.run(debug = True)