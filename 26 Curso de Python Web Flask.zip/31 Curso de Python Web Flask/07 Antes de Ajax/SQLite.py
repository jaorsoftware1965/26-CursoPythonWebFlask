# -------------------------------------------------------------------------------
# Programación para Web con Python y Flask
# Uso de SQLite
# -------------------------------------------------------------------------------

# Importamos librerías
from flask import Flask, render_template, request

# Importamos SQLite
import sqlite3 as sql

# Definimos la aplicación
app = Flask(__name__)

# Función para crear la tabla
def CrearTablaEstudiantes():
    conn = sql.connect('database.db')
    print ("Opened database successfully")

    conn.execute('CREATE TABLE students (name TEXT, addr TEXT, city TEXT, pin TEXT)')
    print ("Table created successfully")
    conn.close()

# Definimos la ruta inicial
@app.route('/')

# Definimos la función Index
def fnIndex():
   return render_template('index.html')

# Definimos la ruta para insertar un nuevo registro
@app.route('/estudiante')

# Función para Insertar un Estudiante
def fnEstudiante():
    # Rederiza al documento html
    return render_template('estudiante.html')

# Define la ruta para insertar un Estudiante
@app.route('/insertarEstudiante',methods = ['POST', 'GET'])

# Función para Insertar un Estudiante
def fnInsertarEstudiante():

    # Verifica que sea POST
    if request.method == 'POST':
        
        # Captura el Error
        try:
            # Obtiene los datos de la forma
            nm   = request.form['nm']
            addr = request.form['add']
            city = request.form['city']
            pin  = request.form['pin']
         
            # Prepara una conexión a la BD
            with sql.connect("database.db") as con:
                
                # Prepara un Cursor
                cur = con.cursor()            
                
                # Ejecuta la Inserción
                cur.execute("INSERT INTO students (name,addr,city,pin) VALUES (?,?,?,?)",(nm,addr,city,pin) )
                
                # Hace un commit
                con.commit()
                
                # Prepara un Mensaje
                mensaje = "El registro se ha insertado exitosamente"
        except:
            # Hace un rollback debido al error
            con.rollback()
            
            # Mensaje de Error
            mensaje = "Error en la operación de Insertar"
      
        finally:
            
            # Cierra la conexión
            con.close()

            # Renderiza a Template de Resultados
            return render_template("resultado.html",msg = mensaje)

# Ruta para listar estudiantes           
@app.route('/listar')

# Función para listar Estudiantes
def fnListar():    

    # Se conecta a la Base de Datos
    con = sql.connect("database.db")
    con.row_factory = sql.Row

    # Crea un cursor
    cur = con.cursor()

    # Ejecuta consultas
    cur.execute("select * from students")

    # Obtiene los recursos
    registrosObtenidos = cur.fetchall()

    # Renderiza listar.html
    return render_template("listar.html",rows = registrosObtenidos)

# Función principal
if __name__ == '__main__':

    # Crea la tabla
    #CrearTablaEstudiantes()

    # Ejecuta el Servidor en Debug
    app.run(debug = True)