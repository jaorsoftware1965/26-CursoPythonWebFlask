
# Importamos las librerías necesarias
from flask import Flask, render_template, request, flash
from forms import FormularioContacto

# Creamos el objeto Flask
app = Flask(__name__)

# La llave secreta
app.secret_key = 'jaorsoftware'

# Definimos la ruta
@app.route('/contact', methods = ['GET', 'POST'])

# Función para contacto
def contact():
    
    # Creamos un objeto formulario
    formulario = FormularioContacto()

    # Verificamos si es post
    if request.method == 'POST':
        # Validamos si no tiene errores
        bSinErrores = formulario.validate()

        # Desplegamos Información del Formulario
        print("Formulario:",formulario)
        print("Tipo de Datos de Errors:",type(formulario.Email.errors))
        print("Email:",formulario.Email)  
        print("Email:",formulario.Email.data)  
        if (formulario.Email.data!="jaorsoftware@gmail.com"):
            formulario.Email.errors.append("Falta el nombre")
        print("Email Errores:",formulario.Email.errors)
        print("Edad Errores:",formulario.Edad.errors)

        # Verificamos si hubo error
        if  bSinErrores:
            # Vamos a formulario de exito
            return render_template('success.html')
        
        else:         
            # Agregagmos mensaje flash
            flash('Todos los datos son requeridos.')

            # Activamos la forma de nuevo
            return render_template('contact.html', form = formulario)
            
    
    # Get entra cuando se accede desde la dirección
    elif request.method == 'GET':
        # Si es método get
        print("------------->GET")
        return render_template('contact.html', form = formulario)

# Función Principal
if __name__ == '__main__':
   app.run(debug = True)