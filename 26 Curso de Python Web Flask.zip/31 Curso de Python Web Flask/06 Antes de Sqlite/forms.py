# -----------------------------------------------------------
# Curso Python para Web con Flask
# Usando WTF, librería para interfaces de Formularios
# -----------------------------------------------------------

# Importamos las librerias
from flask_wtf import Form
from wtforms   import TextField, IntegerField, TextAreaField, SubmitField, RadioField, SelectField
from wtforms   import validators, ValidationError

# Datos que pueden ser utilizados al crear formulario
# 1	TextField
# Represents <input type = 'text'> HTML form element
# 2	BooleanField
# Represents <input type = 'checkbox'> HTML form element
# 3	DecimalField
# Textfield for displaying number with decimals
# 4	IntegerField
# TextField for displaying integer
# 5	RadioField
# Represents <input type = 'radio'> HTML form element
# 6	SelectField
# Represents select form element
# 7	TextAreaField
# Represents <testarea> html form element
# 8	PasswordField
# Represents <input type = 'password'> HTML form element
# 9	SubmitField
# Represents <input type = 'submit'> form element

# Validaciones
# 1	DataRequired
# Checks whether input field is empty
# 2	Email
# Checks whether text in the field follows email ID conventions
# 3	IPAddress
# Validates IP address in input field
# 4	Length
# Verifies if length of string in input field is in given range
# 5	NumberRange
# Validates a number in input field within given range
# 6	URL
# Validates URL entered in input field


# Se define la Clase
class FormularioContacto(Form):

   # Nombre
   Nombre = TextField("Nombre del Estudiante",[validators.DataRequired("Por favor captura tu nombre.")])
   #Nombre = TextField("Nombre del Estudiante",[validators.InputRequired("Por favor captura tu nombre.")])

   # Genero
   Genero = RadioField('Genero', choices = [('M','Masculino'),('F','Femenino')])

   # Dirección
   Direccion = TextAreaField("Dirección")
   
   # Email
   Email = TextField("Email",[validators.DataRequired("Por favor captura tu email."),
           validators.Email("Captura email correcto.")])
   
   # Edad
   Edad = IntegerField("Edad",[validators.NumberRange(18,99,"Rango entre 18 y 99")])

   # Lenguajes
   Lenguajes = SelectField('Lenguajes', choices = [('cpp', 'C++'),('py', 'Python')])

   # Botón de Submit
   submit = SubmitField("Enviar")