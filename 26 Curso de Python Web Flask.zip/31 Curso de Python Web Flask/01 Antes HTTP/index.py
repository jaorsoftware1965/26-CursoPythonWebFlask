# ---------------------------------------------------------------------
# index.py
# Hola Mundo con Python y Flask
# ---------------------------------------------------------------------

# Librería
from flask import Flask, render_template, redirect, url_for 

# Creamos un objeto app de Flask
app = Flask(__name__)

# Indicamos la ruta para la página principal
@app.route("/")

# Definimos una función para la ruta de la página principal
def fnCargaInicio():

    # Ejecuta la carga de la Página Inicial
    return render_template("inicio.html")

# Indicamos la ruta para el Acerca de
@app.route("/acercade")

# Definimos una función para la ruta de la página principal
def fnAcercaDe():
    
    # Ejecutamos la pagina de Acerca de    
    return render_template("acercade.html")

# Definimos una ruta para el administrador
@app.route('/administrador')
def fnAdministrador():
   return 'Hola Administrador'

# Definimos una ruta para el Invitado
@app.route('/invitado/<nombreInvitado>')
def fnInvitado(nombreInvitado):
   return 'Hola %s como Invitado' % nombreInvitado

# Definimos una ruta para el usuarios
@app.route('/usuario/<nombreUsuario>')
def fnUsuario(nombreUsuario):
    if nombreUsuario =='admin':
        # Redireccionamos a ruta de administrador
        #return fnAdministrador()
        #return redirect("/administrador")
        return redirect(url_for('fnAdministrador'))
        
    else:
        #return fnInvitado(nombreUsuario)        
        #return redirect('/invitado/'+nombreUsuario)
        return redirect(url_for('fnInvitado',nombreInvitado = nombreUsuario))

# Función Principal
if __name__ == "__main__":
    
    # Ejecutamos el objeto 
    app.run(debug=True)