# Librerias
from werkzeug.contrib.sessions import FilesystemSessionStore


# Obtiene la Lista
ss = FilesystemSessionStore()

# La Limpia
ss.list().clear()
del ss.list()[0]

contador = 0
# Ciclo para imprimir
for dato in ss.list():
    print(dato)
    contador = contador +1 
    s = ss.get(dato)
    print(s['usuario'])


#s = ss.new()
#s["usuario"]="jaor"
#ss.save(s)
s = ss.get('f4be6d865bb62a86808a7e5c3865be00e4ac4e72')
#s = ss.list[0]
print ("Imprimiendo Usuario:",s["usuario"])
print (contador)


# Función principal
#if __name__ == '__main__':

    # Ejecuta el Servidor en Debug
    #app.run(debug = True)    
    #print("Run")