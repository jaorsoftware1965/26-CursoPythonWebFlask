# ----------------------------------------------------------------------------------
# index.py
# Programación Web con Python y Flask
# ----------------------------------------------------------------------------------

# Librería
from flask import Flask, render_template, redirect, url_for, request, make_response

# Creamos un objeto app de Flask
app = Flask(__name__)

# Indicamos la ruta para la página principal
@app.route("/")

# Definimos una función para la ruta de la página principal
def fnCargaInicio():

    # Ejecuta la carga de la Página Inicial
    return render_template("inicio.html")
    #return render_template("formatoPrincipal.html",titulo="Inicio",cabecera="JaorSoftware Consultor Independiente")

# Indicamos la ruta para el Acerca de
@app.route("/acercade")

# Definimos una función para la ruta de la página acerca de
def fnAcercaDe():
    
    # Ejecutamos la pagina de Acerca de    
    return render_template("acercade.html")
    #return render_template("formatoPrincipal.html",titulo="Acerca de",cabecera="Desarrollado por JaorSoftware")

# Definimos una ruta para el administrador
@app.route('/administrador')
def fnAdministrador():
   return 'Hola Administrador'

# Definimos una ruta para el Invitado
@app.route('/invitado/<nombreInvitado>')
def fnInvitado(nombreInvitado):
   return 'Hola %s como Invitado' % nombreInvitado


# Ruta para hacer login con el Metodo Get
@app.route('/loginGet')
def fnLoginGet():
    # Se obtiene el usuario
    usuarioEmail = request.args.get('usuario') 
    if (usuarioEmail=="admin@email.com"):
        return redirect(url_for('fnAdministrador'))
    else:
        return redirect(url_for('fnInvitado',nombreInvitado = usuarioEmail))
    
# Decorador para procesar la función en la ruta /login   
@app.route('/login',methods = ['POST', 'GET'])

# Función para el Login
def login():
    # Verifico que metodo es
    if request.method == 'POST':
        # Obtiene el Usuario
        usuarioEmail = request.form['emailUsuario']
        print("Usando POST ...")
    else:
        # Obtiene el Usuario
        usuarioEmail = request.args.get("emailUsuario")
        print("Usando GET ...")
        
    if (usuarioEmail=="admin@email.com"):
        return redirect(url_for('fnAdministrador'))
    else:
        return redirect(url_for('fnInvitado',nombreInvitado = "usuarioEmail"))


# Definimos una ruta para el acceso
@app.route('/acceso/<int:nivel>')
def fnAcceso(nivel):
   return render_template('acceso.html', nivelAcceso = nivel)



# Definimo una ruta para resultados
# @app.route('/resultados')
# def fnResultados():
    # # Define un diccionario de datos con calificaciones
    # dicCalificaciones = {'Programación':90,'Análisis de Sistemas':80,'Python':100} 
    # lstMaterias = ['Programación','Análisis de Sistemas','Python',"otra Materia"]
    # #return render_template('resultados.html', calificaciones = dicCalificaciones)
    # return render_template('resultados.html', calificaciones = dicCalificaciones, 
    #                                           materias = lstMaterias)

# Definimos una ruta paa la captura de las calificaciones
@app.route('/alumno')
def fnAlumno():
   return render_template('alumno.html')

# Define la ruta de resultados
@app.route('/resultados',methods = ['POST'])
def result():
    # Obtengo los resultados de la Forma
    resultados = request.form

    # Imprimo el tipo de dato generado
    print(type(resultados))

    # Lo despliego
    print(resultados)

    # Genero un diccionario
    dicCalificaciones = {'Programación':90,'Análisis de Sistemas':80,'Python':100}
    
    # Imprimo el tipo de dato generado
    print(type(dicCalificaciones))

    # Lo despliego
    print(dicCalificaciones)

    # Lanzo el template
    return render_template("resultados.html",calificaciones = resultados)


# Establecemos una ruta para colocar cookie
@app.route('/setcookie', methods = ['POST'])
def setcookie():

    # Obtenemos el emailUsuario
    user = request.form['emailUsuario']
   
    # Ejecutamos el template para obtener la respuesta
    resp = make_response(render_template('registrarcookie.html'))

    # Guardamos la cookie con el nombre userID
    resp.set_cookie('userID3', user)

    print("Resp:",resp)
    print(type(resp))
   
    # Retorna respuesta
    return resp

# Ruta para obtener la cookie
@app.route('/getcookie')
def getcookie():
    name = request.cookies.get('userID3')
    if (name== None):
        return "Hola; es la primera vez que visitas este Sitio"
    else:     
        return '<h1>Bienvenido '+name+'</h1>'

# Función Principal
if __name__ == "__main__":
    
    # Ejecutamos el objeto 
    app.run(debug=True)