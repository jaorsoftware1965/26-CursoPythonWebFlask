// ------------------------------------
// Archivo de Funciones en Java Script
// -----------------------------------

// Función que despliega un mensaje con alert
function fnSayHello() 
{
    // Mensaje
    alert("Hola Usuario")
}

// Función que despliega un mensaje con alert
function fnDespliega(dato) 
{
    // Mensaje
    alert(dato)
}
