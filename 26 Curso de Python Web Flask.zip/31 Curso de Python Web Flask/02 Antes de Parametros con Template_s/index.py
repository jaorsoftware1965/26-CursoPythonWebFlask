# ---------------------------------------------------------------------
# index.py
# Hola Mundo con Python y Flask
# ---------------------------------------------------------------------

# Librería
from flask import Flask, render_template, redirect, url_for, request

# Creamos un objeto app de Flask
app = Flask(__name__)

# Indicamos la ruta para la página principal
@app.route("/")

# Definimos una función para la ruta de la página principal
def fnCargaInicio():

    # Ejecuta la carga de la Página Inicial
    return render_template("inicio.html")

# Indicamos la ruta para el Acerca de
@app.route("/acercade")

# Definimos una función para la ruta de la página acerca de
def fnAcercaDe():
    
    # Ejecutamos la pagina de Acerca de    
    return render_template("acercade.html")


# Definimos una ruta para el administrador
@app.route('/administrador')
def fnAdministrador():
   return 'Hola Administrador'

# Definimos una ruta para el Invitado
@app.route('/invitado/<nombreInvitado>')
def fnInvitado(nombreInvitado):
   return 'Hola %s como Invitado' % nombreInvitado


# Ruta para hacer login con el Metodo Get
@app.route('/loginGet')
def fnLoginGet():
    # Se obtiene el usuario
    usuarioEmail = request.args.get('usuario') 
    if (usuarioEmail=="admin@email.com"):
        return redirect(url_for('fnAdministrador'))
    else:
        return redirect(url_for('fnInvitado',nombreInvitado = usuarioEmail))
    
# Decorador para procesar la función en la ruta /login   
@app.route('/login',methods = ['POST', 'GET'])

# Función para el Login
def login():
    # Verifico que metodo es
    if request.method == 'POST':
        # Obtiene el Usuario
        usuarioEmail = request.form['emailUsuario']
        print("Usando POST ...")
    else:
        # Obtiene el Usuario
        usuarioEmail = request.args.get("emailUsuario")
        print("Usando GET ...")
        
    if (usuarioEmail=="admin@email.com"):
        return redirect(url_for('fnAdministrador'))
    else:
        return redirect(url_for('fnInvitado',nombreInvitado = "usuarioEmail"))
    

# Función Principal
if __name__ == "__main__":
    
    # Ejecutamos el objeto 
    app.run(debug=True)