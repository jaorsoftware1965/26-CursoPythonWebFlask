# ------------------------------------------------------------------------------------------
# index.py
# Programación Web con Python y Flask
# ------------------------------------------------------------------------------------------

# Librería
from flask import Flask, flash, redirect, render_template, request, url_for
from werkzeug.utils import secure_filename
import os

# Es posible definir la ruta donde los archivos son cargados y tambien el tamño máximo permitido
# con los siguientes  Flask object.

#app.config[‘UPLOAD_FOLDER’]	Defines path for upload folder
#app.config[‘MAX_CONTENT_PATH’]	Specifies maximum size of file yo be uploaded – in bytes

# Creal el Objeto flask
app = Flask(__name__)

# Configura ruta de descargas
app.config['UPLOAD_FOLDER']="descargas"
app.config['MAX_CONTENT_PATH']=101935

# Decorador Interceptor a upload
@app.route('/')

# Función Index
def index():
   return render_template('upload.html')
	
# Decorador para cargar archivos
@app.route('/uploader', methods = ['GET', 'POST'])

# Función para cargar archivos
def upload_file():
    # VErifica si el método es request
    if request.method == 'POST':
        
        # Obtiene el nombre del Archivo
        fArchivo = request.files['nombreArchivo']

        # El nombre del Archivo
        print("Archivo:",fArchivo.filename)
        
        # Obtengo la Longitud del Archivo
        blob = request.files['nombreArchivo'].read()
        longitud = len(blob)
        print("Longitud:",longitud)

        # Verificamos que la longitud no exceda
        if (longitud < app.config['MAX_CONTENT_PATH']):

            # Guarda el Archivo
            #fArchivo.save(secure_filename(fArchivo.filename))
            #fArchivo.save(secure_filename("/descargas/"+fArchivo.filename))
            #fArchivo.save(os.path.join(app.config['UPLOAD_FOLDER'], secure_filename(fArchivo.filename)))
            fArchivo.save(os.path.join("descargas", secure_filename(fArchivo.filename)))

            # Mensaje
            return 'El archivo fué cargado con éxito'
        else:
		    # Mensaje
            return "El Archivo excede la longitud permitida"

# Función principal
if __name__ == "__main__":
    # Ejecuta el Servidor
    app.run(debug = True)